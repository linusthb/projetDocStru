package DOM;

import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.ArrayList;
public class projetdoc{
	static DocumentBuilder parser;
	public static  DOMImplementation imp() {
		return parser.getDOMImplementation();
	}

	public static void main(String[] args) throws Exception{
		DocumentBuilderFactory t = DocumentBuilderFactory.newInstance();
		t.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		parser = t.newDocumentBuilder();
		recursive("projet");

	}
	public static void recursive(String path) throws Exception {
		String[] files = (new File(path)).list();
		assert files != null;
		for(String s : files) {
			String filePath = path + File.separator + s;
			File f = new File(filePath);
			if(f.isDirectory())
				recursive(filePath);
			else
				if(s.contains("renault.html"))
					renault(filePath);
				else if(s.contains("boitedialog.fxml"))
					boite(filePath);
				else if(s.contains("M457.xml"))
					M457(filePath);
				else if(s.contains("M674.xml"))
					M674(filePath);
				else if(s.contains("poeme.txt"))
					poeme(filePath);
				else if(s.contains("fiches.txt")) {
					fiche1(filePath);
					fiche2(filePath);
				}
		}
	}


public static void renault(String xmlFile) throws Exception{
	/*je recup�re les infos de strong et p, je les mets dans une lister 'array' de type 'item' , puis classe la liste
	 pour avoir les 14 ref avec nom add et tel puis je cree simplement le fichier de sortie*/
		final Document document= parser.parse(new File(xmlFile));
		final Element racine = document.getDocumentElement();
		NodeList mot =  racine.getElementsByTagName("p");
		class item {
			String nom=null;
			String add=null;
			String tel=null;

			boolean isNotEmpty() {
				return nom !=null || add != null || tel != null ;
			}
		}
		String contenuadd="",contenutel="";
		ArrayList<item> array = new ArrayList<>();
		for (int i=0;i<14;i++){
			item el1 = new item();
			NodeList liste = mot.item(i).getChildNodes();
			for (int j=0;j<liste.getLength();j++){
				if(liste.item(j).getNodeValue()!=null &&  !liste.item(j).getNodeValue().replace("\n","").replace("\t", "").replace(" ","").isEmpty())
					contenuadd=liste.item(6).getNodeValue().replace("\n","");

			}
			el1.add=contenuadd.replace(": ", "");

			if(el1.isNotEmpty()) array.add(el1);

		}

		for (int i=0;i<14;i++){
			item el1 = new item();
			NodeList liste = mot.item(i).getChildNodes();
			for (int j=0;j<liste.getLength();j++){
				if(liste.item(j).getNodeValue()!=null &&  !liste.item(j).getNodeValue().replace("\n","").replace("\t", "").replace(" ","").isEmpty())

					if(i==1) {contenutel=liste.item(10).getNodeValue().replace("\n","");}else {
						contenutel=liste.item(8).getNodeValue().replace("\n","");
					}
			}
			el1.tel=contenutel.replace(": ", "").replace(" 0","0");

			if(el1.isNotEmpty()) array.add(el1);

		}

		NodeList mott =  racine.getElementsByTagName("strong");

		for (int i=0;i<mott.getLength();i++){
			NodeList liste = mott.item(i).getChildNodes();
			for (int j=0;j<liste.getLength();j++){
				item el1 = new item();
				if(liste.item(j).getNodeValue()!=null &&  !liste.item(j).getNodeValue().replace("\n","").replace("\t", "").replace(" ","").isEmpty())
				{
					el1.nom= liste.item(0).getNodeValue().replace("\n","");
				}
				if(el1.isNotEmpty()) array.add(el1);
			}
		}
		//for(conss el1 : array) System.out.println("le nom "+el1.nom+ " l'add "+el1.add+" le telephone "+el1.tel);


		int k=0;





		for(item el1 : array) {
			if(k==1) {el1.tel=array.get(15).tel;el1.nom=array.get(28).nom;}
			if(k==2) {el1.tel=array.get(16).tel;el1.nom=array.get(31).nom;el1.add=el1.add.replace(" A", "A");}
			if(k==3) {el1.tel=array.get(17).tel;el1.nom=array.get(37).nom;el1.add=el1.add.replace(" R", "R");}
			if(k==4) {el1.tel=array.get(18).tel;el1.nom=array.get(43).nom;el1.add=el1.add.replace(" 1", "1");}
			if(k==5) {el1.tel=array.get(19).tel;el1.nom=array.get(49).nom;el1.add=el1.add.replace(" 07", "07");}
			if(k==6) {el1.tel=array.get(20).tel;el1.nom=array.get(55).nom;el1.add=el1.add.replace(" G", "G");}
			if(k==7) {el1.tel=array.get(21).tel;el1.nom=array.get(61).nom;el1.add=el1.add.replace(" 17", "17");}
			if(k==8) {el1.tel=array.get(22).tel;el1.nom=array.get(67).nom;el1.add=el1.add.replace(" C", "C");}
			if(k==9) {el1.tel=array.get(23).tel;el1.nom=array.get(73).nom;el1.add=el1.add.replace(" Z", "Z").replace("12Zeralda", "12 Zeralda");}
			if(k==10) {el1.tel=array.get(24).tel;el1.nom=array.get(79).nom;el1.add=el1.add.replace(" 40", "40").replace("ElHammamet", "El Hammamet");}
			if(k==11) {el1.tel=array.get(25).tel;el1.nom=array.get(85).nom;el1.add=el1.add.replace(" 06", "06");}
			if(k==12) {el1.tel=array.get(26).tel;el1.nom=array.get(91).nom;el1.add=el1.add.replace(" 60", "60").replace("ElB", "El B");}
			if(k==13) {el1.tel=array.get(27).tel.replace("3717","37 17");el1.nom=array.get(97).nom;el1.add=el1.add.replace("HusseinDey", "Hussein Dey");}
			//System.out.println(" num "+k+"le nom "+el1.nom+ " l'add "+el1.add+" le telephone "+el1.tel);
			k++;
		}

		DOMImplementation domimp = imp();

		Document document_but =	domimp.createDocument(null,"Concessionnaires", null);
		document_but.setXmlStandalone(true);
		Element rac_but= document_but.getDocumentElement();





		for (int j=1;j<14;j++){




			Element nom = document_but.createElement("Nom");
			rac_but.appendChild(nom);
			nom.appendChild(document_but.createTextNode(array.get(j).nom));

			Element add = document_but.createElement("Adresse");
			rac_but.appendChild(add);
			add.appendChild(document_but.createTextNode(array.get(j).add));

			Element tel = document_but.createElement("Num_t�l�phone");
			rac_but.appendChild(tel);
			tel.appendChild(document_but.createTextNode(array.get(j).tel));

		}

		StreamResult res = new StreamResult(new File("Resultat/renault.xml"));


		TransformerFactory transform = TransformerFactory.newInstance();
		Transformer tr = transform.newTransformer();

		//tr.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION.replace("standalone=\"no\"", ""), "no");
		DOMSource ds = new DOMSource(document_but);
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC,"");
		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/renault.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/renault.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();
	}

public static void boite(String xmlFile1) throws Exception{
	/* pour java fx je recupere les attributs de chaque noeuds et leurs valeurs  dans une liste 'li' de type 'boite'
	 * les attributs seront d�sordonn�s je  classe donc la liste de facon a avoir le meme classement que dans le fichier source
	 * en suite je cr�e la sortie  */
		Document document_src = parser.parse(xmlFile1);
		DOMImplementation domImplementation = imp();

		Document document_but =	domImplementation.createDocument(null,"Racine", null);
		document_but.setXmlStandalone(true);
		Element rac_but= document_but.getDocumentElement();
		rac_but.setAttribute("xmlns:fx", "http://javafx.com/fxml");
		class boite {
			String nom = null;
			String Att = null;
		}
		ArrayList <boite> li = new ArrayList <> ();

		NodeList mot =  document_src.getElementsByTagName("GridPane");

		for (int i=0;i<mot.getLength();i++){
			NamedNodeMap atts = mot.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){

				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();
				String val = attr.getValue();
				boite c = new boite();
				c.nom=nom;
				li.add(c);
				c.Att=val;}}

		NodeList mott =  document_src.getElementsByTagName("ImageView");
		for (int i=0; i<mott.getLength(); i++){
			NamedNodeMap attributes = mott.item(i).getAttributes();
			for( int e = 0; e < attributes.getLength(); e++ ){

				Attr attr = (Attr) attributes.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;
				c.Att=val;li.add(c);}}

		NodeList mo =  document_src.getElementsByTagName("VBox");
		for (int i=0;i<mo.getLength();i++){

			NamedNodeMap atts = mo.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}


		NodeList vo =  document_src.getElementsByTagName("Label");
		for (int i=0;i<vo.getLength();i++){
			{ NamedNodeMap attributes = vo.item(i).getAttributes();
				for( int e = 0; e < attributes.getLength(); e++ ){
					Attr attr = (Attr) attributes.item(e);String nom = attr.getName();String val = attr.getValue();boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}}
		NodeList font =  document_src.getElementsByTagName("Font");
		for (int i=0;i<font.getLength();i++){  NamedNodeMap atts = font.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);String nom = attr.getName();String val = attr.getValue();boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}

		NodeList vi =  document_src.getElementsByTagName("HBox");
		for (int i=0;i<vi.getLength();i++){  NamedNodeMap atts = vi.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);String nom = attr.getName();String val = attr.getValue();boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}

		NodeList pane =  document_src.getElementsByTagName("Pane");
		for (int i=0;i<mott.getLength();i++){
			NamedNodeMap atts = pane.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}

		NodeList button =  document_src.getElementsByTagName("Button");
		for (int i=0;i<mott.getLength();i++){
			NamedNodeMap atts = button.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}

		NodeList colum =  document_src.getElementsByTagName("ColumnConstraints");
		for (int i=0;i<colum.getLength();i++){
			NamedNodeMap atts = colum.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}

		NodeList columm =  document_src.getElementsByTagName("Insets");
		for (int i=0;i<columm.getLength();i++){
			NamedNodeMap atts = columm.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}





		NodeList Insets =  document_src.getElementsByTagName("RowConstraints");
		for (int i=0;i<Insets.getLength();i++){
			NamedNodeMap atts = Insets.item(i).getAttributes();
			for( int e = 0; e < atts.getLength(); e++ ){
				Attr attr = (Attr) atts.item(e);
				String nom = attr.getName();String val = attr.getValue();
				boite c = new boite();c.nom=nom;c.Att=val;li.add(c);}}



		boite h = new boite();
		h.Att=li.get(28).Att;h.nom=li.get(28).nom;	li.get(28).Att=li.get(32).Att;li.get(28).nom=li.get(32).nom;li.get(32).Att=h.Att;li.get(32).nom=h.nom;
		h.Att=li.get(29).Att;h.nom=li.get(29).nom;li.get(29).Att=li.get(33).Att;li.get(29).nom=li.get(33).nom;li.get(33).Att=h.Att;li.get(33).nom=h.nom;
		h.Att=li.get(30).Att;h.nom=li.get(30).nom;li.get(30).Att=li.get(32).Att;li.get(30).nom=li.get(32).nom;li.get(32).Att=h.Att;li.get(32).nom=h.nom;
		h.Att=li.get(31).Att;h.nom=li.get(31).nom;li.get(31).Att=li.get(33).Att;li.get(31).nom=li.get(33).nom;li.get(33).Att=h.Att;li.get(33).nom=h.nom;

		h.Att=li.get(43).Att;h.nom=li.get(43).nom;li.get(43).Att=li.get(45).Att;li.get(43).nom=li.get(45).nom;li.get(45).Att=h.Att;li.get(45).nom=h.nom;
		h.Att=li.get(44).Att;h.nom=li.get(44).nom;li.get(44).Att=li.get(46).Att;li.get(44).nom=li.get(46).nom;li.get(46).Att=h.Att;li.get(46).nom=h.nom;

		h.Att=li.get(45).Att;h.nom=li.get(45).nom;li.get(45).Att=li.get(47).Att;li.get(45).nom=li.get(47).nom;li.get(47).Att=h.Att;li.get(47).nom=h.nom;
		h.Att=li.get(46).Att;h.nom=li.get(46).nom;li.get(46).Att=li.get(48).Att;li.get(46).nom=li.get(48).nom;li.get(48).Att=h.Att;li.get(48).nom=h.nom;

		h.Att=li.get(47).Att;h.nom=li.get(47).nom;li.get(47).Att=li.get(49).Att;li.get(47).nom=li.get(49).nom;li.get(49).Att=h.Att;li.get(49).nom=h.nom;
		h.Att=li.get(48).Att;h.nom=li.get(48).nom;li.get(48).Att=li.get(50).Att;li.get(48).nom=li.get(50).nom;li.get(50).Att=h.Att;li.get(50).nom=h.nom;

		h.Att=li.get(49).Att;h.nom=li.get(49).nom;li.get(49).Att=li.get(51).Att;li.get(49).nom=li.get(51).nom;li.get(51).Att=h.Att;li.get(51).nom=h.nom;
		h.Att=li.get(50).Att;h.nom=li.get(50).nom;li.get(50).Att=li.get(52).Att;li.get(50).nom=li.get(52).nom;li.get(52).Att=h.Att;li.get(52).nom=h.nom;

		h.Att=li.get(51).Att;h.nom=li.get(51).nom;li.get(51).Att=li.get(53).Att;li.get(51).nom=li.get(53).nom;li.get(53).Att=h.Att;li.get(53).nom=h.nom;
		h.Att=li.get(52).Att;h.nom=li.get(52).nom;li.get(52).Att=li.get(53).Att;li.get(52).nom=li.get(53).nom;li.get(53).Att=h.Att;li.get(53).nom=h.nom;


		for (boite boite : li) {
			Element text = document_but.createElement("texte");
			rac_but.appendChild(text);
			text.appendChild(document_but.createTextNode(boite.Att));
			text.setAttribute(boite.nom, "x");
		}
		StreamResult res = new StreamResult(new File("Resultat/javafx.xml"));


		TransformerFactory transform = TransformerFactory.newInstance();
		Transformer tr = transform.newTransformer();


		DOMSource ds = new DOMSource(document_but);
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC,"");
		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/javafx.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/javafx.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();
	}
	public static void M457(String xmlFile2) throws Exception{
	/*je recupere simplement les textes contenus dans p et cr�e le document de sortie*/
		Document document_src = parser.parse(xmlFile2);
		DOMImplementation domImplementation = imp();

		Document document_but =	domImplementation.createDocument(null,"TEI_S", null);
		document_but.setXmlStandalone(true);
		Element rac_but= document_but.getDocumentElement();

		Element but = document_but.createElement("M457.xml");
		rac_but.appendChild(but);
		NodeList mot =  document_src.getElementsByTagName("p");


		for (int i=0;i<mot.getLength();i++){
			NodeList list = mot.item(i).getChildNodes();

			for (int j=0;j<list.getLength();j++){

				if(list.item(j).getNodeValue()!=null &&  !list.item(j).getNodeValue().replace("\n","").replace("\t", "").replace(" ","").isEmpty())
				{	String content=list.item(j).getNodeValue().replace("\n","");


					Element texte = document_but.createElement("texte");
					but.appendChild(texte);
					texte.appendChild(document_but.createTextNode(content));} } }
		StreamResult res = new StreamResult(new File("Resultat/Sortie2.xml"));


		TransformerFactory transform = TransformerFactory.newInstance();
		Transformer tr = transform.newTransformer();


		DOMSource ds = new DOMSource(document_but);
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "dom.dtd");
		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/Sortie2.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/Sortie2.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();
	}
public static void M674(String xmlFile3) throws Exception{
	/*je recupere simplement les textes contenus dans p et cr�e le document de sortie*/
		Document document_src = parser.parse(xmlFile3);
		DOMImplementation domImplementation = imp();

		Document document_but =	domImplementation.createDocument(null,"TEI_S", null);
		Element rac_but= document_but.getDocumentElement();

		document_but.setXmlStandalone(true);
		Element but = document_but.createElement("M674.xml");
		rac_but.appendChild(but);
		NodeList mot =  document_src.getElementsByTagName("p");


				 for (int i=0;i<mot.getLength();i++){
				 NodeList liste = mot.item(i).getChildNodes();

					 for (int j=0;j<liste.getLength();j++){

						if(liste.item(j).getNodeValue()!=null &&  !liste.item(j).getNodeValue().replace("\n","").replace("\t", "").replace(" ","").isEmpty())
						{	String contenu=liste.item(j).getNodeValue().replace("\n","");


		Element texte = document_but.createElement("texte");
		but.appendChild(texte);
		texte.appendChild(document_but.createTextNode(contenu));} } }
		StreamResult res = new StreamResult(new File("Resultat/Sortie1.xml"));


		TransformerFactory transform = TransformerFactory.newInstance();
		Transformer tr = transform.newTransformer();


		DOMSource ds = new DOMSource(document_but);
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "dom.dtd");
		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/Sortie1.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/Sortie1.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();
	}
public static void fiche1(String xmlFile4) throws Exception{
	/*je partage le fichier en parties grace au split  puis cr�� le fichier de sortie*/
		DOMImplementation domImplementation = parser.getDOMImplementation();
		Document doc = domImplementation.createDocument(null,"FICHES",null);
		doc.setXmlStandalone(true);
		String fichier = "";
		String ligne;
		BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(new FileInputStream(xmlFile4), "UTF8"));
		while((ligne = bufferedReader.readLine())!=null)  fichier+="\n"+ligne;
		fichier = fichier.replaceAll("[ \t]*\n[ \t]*\n[ \t]*(\n[ \t]*)*", "\n\n");
		final String[] fichesStr = fichier.split("\n\n");
		class Fiche {
			String head = null;
			String AR = null;
			String FR = null;
		}
		Fiche[] fiches = new Fiche[4];
		for (int i = 0; i < 4; i++) {
			Fiche f = new Fiche();
			String[] parties = fichesStr[i].split("\nAR *\n");
			f.head = parties[0];
			parties = parties[1].split("\nFR\n");
			f.AR = parties[0];
			f.FR = parties[1];
			fiches[i] = f;
		}

		for(int i=0; i<4; i++) {
			ArrayList<Element> header = new ArrayList<>();
			Element fiche = doc.createElement("FICHE");
			fiche.setAttribute("id", ""+(i+1));
			doc.getDocumentElement().appendChild(fiche);
			for(String line : fiches[i].head.split("\n")) {
				if(line.replaceAll("[ \t]+", "").equals("")) continue;
				String t = null;
				String[] words = line.replaceAll("\t" ," ").replaceAll(" {2}", " ").split(" ");
				for (int j = words.length-1; j >= 0; j--) {
					if(words[j].equals(":")) continue;
					if(words[j].endsWith(":")) words[j]=words[j].replace(":", "");
					if(words[j].length() == 2 && words[j].charAt(0) >='A' && words[j].charAt(0) <='Z' && words[j].charAt(1) >='A' && words[j].charAt(1) <='Z') t = words[j];
					else break;
				}
				if(t == null) continue;
				Element element = doc.createElement(t);
				element.appendChild(doc.createTextNode((t.equals("BE") ? "" : t + " : ") + line.substring(0, line.lastIndexOf(t))));
				if(t.equals("BE") || t.equals("TY") || t.equals("AU"))
					fiche.appendChild(element);
				else
					header.add(element);
			}

			Element lang = doc.createElement("Langue");
			lang.setAttribute("id", "AR");
			for(Element e : header)
				lang.appendChild(e);
			fiche.appendChild(lang);
			boolean isAfterRF = false, justABool = true;
			for(String line : fiches[i].AR.split("\n")) {
				if(line.replaceAll("[ \t]+", "").equals("")) continue;
				ArrayList<String> s = new ArrayList<>();
				String[] words = line.replaceAll("\t" ," ").replaceAll(" {2}", " ").split(" ");
				for (int j = words.length-1; j >= 0; j--) {
					if(words[j].equals(":")) continue;
					if(words[j].endsWith(":")) words[j]=words[j].replace(":", "");
					if(words[j].length() == 2 && words[j].charAt(0) >='A' && words[j].charAt(0) <='Z' && words[j].charAt(1) >='A' && words[j].charAt(1) <='Z') s.add(words[j]);
					else break;
				}
				if(s.size() == 0) continue;
				if(s.get(0).equals("RF")) {
					isAfterRF = true;
					s.remove("RF");
				}
				Element element = doc.createElement(isAfterRF?"RF":s.get(0));
				String prefix = isAfterRF?"RF | ":"";
				for (String value : s) {
					prefix += value + " : ";
				}
				element.appendChild(doc.createTextNode(prefix + line.substring(0, line.lastIndexOf(s.get(s.size()-1))) + (isAfterRF&&justABool?" ":"") + (isAfterRF?"\t":"")));
				if(isAfterRF&&justABool) justABool = false;
				lang.appendChild(element);
			}

			lang = doc.createElement("Langue");
			lang.setAttribute("id", "FR");
			for(Element e : header)
				lang.appendChild(e.cloneNode(true));
			fiche.appendChild(lang);
			isAfterRF = false;
			justABool = true;
			for(String line : fiches[i].FR.split("\n")) {
				if(line.replaceAll("[ \t]+", "").equals("")) continue;
				ArrayList<String> s = new ArrayList<>();
				String[] words = line.replaceAll("\t" ," ").replaceAll(" {2}", " ").split(" ");
				for (int j = words.length-1; j >= 0; j--) {
					if(words[j].equals(":")) continue;
					if(words[j].endsWith(":")) words[j]=words[j].replace(":", "");
					if(words[j].length() == 2 && words[j].charAt(0) >='A' && words[j].charAt(0) <='Z' && words[j].charAt(1) >='A' && words[j].charAt(1) <='Z') s.add(words[j]);
					else break;
				}
				if(s.size() == 0) continue;
				if(s.get(0).equals("RF")) {
					isAfterRF = true;
					s.remove("RF");
				}
				Element element = doc.createElement(isAfterRF?"RF":s.get(0));
				String prefix = isAfterRF?"RF | ":"";
				for (String value : s) {
					prefix += value + " : ";
				}
				element.appendChild(doc.createTextNode(prefix + line.substring(0, line.lastIndexOf(s.get(s.size()-1))) + (isAfterRF&&justABool?" ":"") + (isAfterRF?"\t":"")));
				if(isAfterRF&&justABool) justABool = false;
				
				lang.appendChild(element);
			}
		}



		DOMSource ds = new DOMSource(doc);

		StreamResult res = new StreamResult(new File("Resultat/fiches1.xml"));
		TransformerFactory transform = TransformerFactory.newInstance();
		Transformer tr = transform.newTransformer();
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC,"");

		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.setOutputProperty(OutputKeys.ENCODING, "UTF8");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/fiches1.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/fiches1.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();

}
public static void fiche2(String xmlFile4) throws Exception{
	/*je partage le fichier en parties grace au split  puis cr�� le fichier de sortie*/
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();//Construction d'un parseur.
		DocumentBuilder parseur = factory.newDocumentBuilder();//Construction d'un parseur.
		DOMImplementation domimp = parseur.getDOMImplementation();
		Document doc = domimp.createDocument(null,"FICHES",null);
		doc.setXmlStandalone(true);
		String fichier = "";
		String ligne;
		
		BufferedReader lecteurAvecBuffer= new BufferedReader(new InputStreamReader(new FileInputStream(xmlFile4), "UTF8"));
		while((ligne = lecteurAvecBuffer.readLine())!=null)  fichier+="\n"+ligne;

		fichier = fichier.replaceAll("[ \t]*\n[ \t]*\n[ \t]*(\n[ \t]*)*", "\n\n");
		final String[] fichesStr = fichier.split("\n\n");
		class Fiche {
			String head = null;
			String AR = null;
			String FR = null;
		}
		Fiche[] fiches = new Fiche[4];
		for (int i = 0; i < 4; i++) {
			Fiche f = new Fiche();
			String[] parties = fichesStr[i].split("\nAR *\n");
			f.head = parties[0];
			parties = parties[1].split("\nFR\n");
			f.AR = parties[0];
			f.FR = parties[1];
			fiches[i] = f;
		}

	for(int i=0; i<4; i++) {
			Element fiche = doc.createElement("FICHE");
			fiche.setAttribute("id", ""+(i+1));
			doc.getDocumentElement().appendChild(fiche);
			for(String line : fiches[i].head.split("\n")) {
				if(line.replaceAll("[ \t]+", "").equals("")) continue;
				String t = null;
				String[] words = line.replaceAll("\t" ," ").replaceAll(" {2}", " ").split(" ");
				for (int j = words.length-1; j >= 0; j--) {
					if(words[j].equals(":")) continue;
					if(words[j].endsWith(":")) words[j]=words[j].replace(":", "");
					if(words[j].length() == 2 && words[j].charAt(0) >='A' && words[j].charAt(0) <='Z' && words[j].charAt(1) >='A' && words[j].charAt(1) <='Z') t = words[j];
					else break;
				}
				if(t == null) continue;
				Element element = doc.createElement(t);
				element.appendChild(doc.createTextNode((t.equals("BE") ? "" : t + " : ") + line.substring(0, line.lastIndexOf(t))));
				fiche.appendChild(element);
			}

			Element lang = doc.createElement("Langue");
			lang.setAttribute("id", "AR");
			fiche.appendChild(lang);
			boolean isAfterRF = false;
			for(String line : fiches[i].AR.split("\n")) {
				if(line.replaceAll("[ \t]+", "").equals("")) continue;
				ArrayList<String> s = new ArrayList<>();
				String[] words = line.replaceAll("\t" ," ").replaceAll(" {2}", " ").split(" ");
				for (int j = words.length-1; j >= 0; j--) {
					if(words[j].equals(":")) continue;
					if(words[j].endsWith(":")) words[j]=words[j].replace(":", "");
					if(words[j].length() == 2 && words[j].charAt(0) >='A' && words[j].charAt(0) <='Z' && words[j].charAt(1) >='A' && words[j].charAt(1) <='Z') s.add(words[j]);
					else break;
				}
				if(s.size() == 0) continue;
				if(s.get(0).equals("RF")) {
					isAfterRF = true;
					s.remove("RF");
				}
				Element element = doc.createElement(isAfterRF?"RF":s.get(0));
				String prefix = isAfterRF?"RF | ":"";
				for (String value : s) {
					prefix += value + " : ";
				}
				element.appendChild(doc.createTextNode(prefix + line.substring(0, line.lastIndexOf(s.get(s.size()-1))) + (isAfterRF?"\t":"")));
				//element.appendChild(doc.createTextNode(prefix + line.substring(0, line.lastIndexOf(s.get(s.size()-1)))));
				lang.appendChild(element);
			}

			lang = doc.createElement("Langue");
			lang.setAttribute("id", "FR");
			fiche.appendChild(lang);
			isAfterRF = false;
			for(String line : fiches[i].FR.split("\n")) {
				if(line.replaceAll("[ \t]+", "").equals("")) continue;
				ArrayList<String> s = new ArrayList<>();
				String[] words = line.replaceAll("\t" ," ").replaceAll(" {2}", " ").split(" ");
				for (int j = words.length-1; j >= 0; j--) {
					if(words[j].equals(":")) continue;
					if(words[j].endsWith(":")) words[j]=words[j].replace(":", "");
					if(words[j].length() == 2 && words[j].charAt(0) >='A' && words[j].charAt(0) <='Z' && words[j].charAt(1) >='A' && words[j].charAt(1) <='Z') s.add(words[j]);
					else break;
				}
				if(s.size() == 0) continue;
				if(s.get(0).equals("RF")) {
					isAfterRF = true;
					s.remove("RF");
				}
				Element element = doc.createElement(isAfterRF?"RF":s.get(0));
				String prefix = isAfterRF?"RF | ":"";
				for (String value : s) {
					prefix += value + " : ";
				}
				element.appendChild(doc.createTextNode(prefix + line.substring(0, line.lastIndexOf(s.get(s.size()-1))) + (isAfterRF?"\t":"")));
				//element.appendChild(doc.createTextNode(prefix + line.substring(0, line.lastIndexOf(s.get(s.size()-1)))));
				lang.appendChild(element);
			}
		}
		DOMSource ds = new DOMSource(doc);
		StreamResult res = new StreamResult(new File("Resultat/fiches2.xml"));
		TransformerFactory transform = TransformerFactory.newInstance();

		Transformer tr = transform.newTransformer();
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC,"");
		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.setOutputProperty(OutputKeys.ENCODING, "UTF8");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/fiches2.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/fiches2.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();
}
public static void poeme(String xmlFile5) throws Exception{
/* dans cette premiere partie je lis le fichier puuis je cr�e un fichier source en analysant le texte ligne par ligne
 * pour eviter les lignes vides  */
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();//Construction d'un parseur.
		DocumentBuilder parseur = factory.newDocumentBuilder();//Construction d'un parseur.
		DOMImplementation domimp = parseur.getDOMImplementation();
		Document doc = domimp.createDocument(null,"poema",null);
		doc.setXmlStandalone(true);
				doc.setXmlStandalone(true);
				Element rac = doc.getDocumentElement();
				String titre="titre", p="p",pp="pp";
			      BufferedReader lecteurAvecBuffer;

			  	lecteurAvecBuffer= new BufferedReader(new InputStreamReader(
		                new FileInputStream(xmlFile5), "UTF8"));



				//Cr�ation du deuxi�me n�ud  d'attribut.

		//*****************************************************************************************************//
				//Cr�ation d'un premier n�ud d'�l�ment.
				Element prem_ele_FR = doc.createElement(titre);
				//Ajout de ce premier n�ud d'�l�ment au n�ud d'�l�ment racine.
				rac.appendChild(prem_ele_FR);

				//Cr�ation d'un deuxi�me n�ud d'�l�ment.
				Element prem_el1 = doc.createElement(pp);Element prem_el2 = doc.createElement(pp);Element prem_el3 = doc.createElement(pp);Element prem_el4 = doc.createElement(pp);Element prem_el5 = doc.createElement(pp);
				rac.appendChild(prem_el1);rac.appendChild(prem_el2);rac.appendChild(prem_el3);rac.appendChild(prem_el4);rac.appendChild(prem_el5);
				Element prem_ele11 = doc.createElement(p);Element prem_ele12 = doc.createElement(p);Element prem_ele13 = doc.createElement(p);Element prem_ele14 = doc.createElement(p);
				Element prem_ele21 = doc.createElement(p);Element prem_ele22 = doc.createElement(p);	Element prem_ele23 = doc.createElement(p);	Element prem_ele24 = doc.createElement(p);
				Element prem_ele31 = doc.createElement(p);Element prem_ele32 = doc.createElement(p);Element prem_ele33 = doc.createElement(p);Element prem_ele34 = doc.createElement(p);
				Element prem_ele41 = doc.createElement(p);Element prem_ele42 = doc.createElement(p);Element prem_ele43 = doc.createElement(p);Element prem_ele44 = doc.createElement(p);Element prem_ele45 = doc.createElement(p);
				Element prem_ele51 = doc.createElement(p);Element prem_ele52 = doc.createElement(p);Element prem_ele53 = doc.createElement(p);Element prem_ele54 = doc.createElement(p);
				//Ajout de ce deuxi�me n�ud d'�l�ment au n�ud d'�l�ment racine.

				prem_el1.appendChild(prem_ele11);prem_el1.appendChild(prem_ele12);prem_el1.appendChild(prem_ele13);prem_el1.appendChild(prem_ele14);
				prem_el2.appendChild(prem_ele21);prem_el2.appendChild(prem_ele22);prem_el2.appendChild(prem_ele23);prem_el2.appendChild(prem_ele24);
				prem_el3.appendChild(prem_ele31);prem_el3.appendChild(prem_ele32);prem_el3.appendChild(prem_ele33);prem_el3.appendChild(prem_ele34);
				prem_el4.appendChild(prem_ele41);prem_el4.appendChild(prem_ele42);prem_el4.appendChild(prem_ele43);prem_el4.appendChild(prem_ele44);prem_el4.appendChild(prem_ele45);
				prem_el5.appendChild(prem_ele51);prem_el5.appendChild(prem_ele52);prem_el5.appendChild(prem_ele53);prem_el5.appendChild(prem_ele54);
		//*****************************************************************************************************//
				//Cr�ation d'un premier n�ud de texte et ajout de ce noeud au premier �l�ment "langue".

			      prem_ele_FR.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      prem_ele11.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele12.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele13.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele14.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      prem_ele21.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele22.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele23.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele24.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      prem_ele31.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele32.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele33.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele34.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      prem_ele41.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			       prem_ele42.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele43.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele44.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele45.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      lecteurAvecBuffer.readLine();
			      prem_ele51.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele52.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele53.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      prem_ele54.appendChild((doc.createTextNode(lecteurAvecBuffer.readLine())));
			      lecteurAvecBuffer.readLine();



				//Cr�ation d'un deuxi�me n�ud de texte et ajout de ce noeud au deuxi�me �l�ment "langue".

		//*****************************************************************************************************//
				//Cr�ation de l'objet source, qui est instance
				//de la classe "javax.xml.transform.dom.DOMSource".
				DOMSource ds = new DOMSource(doc);
				//Cr�ation de l'objet r�sultat, qui est instance
				//de la classe "javax.xml.transform.stream.StreamResult".
				StreamResult res = new StreamResult(new File("create.xml"));
				//Nous pouvons utiliser la ligne de code ci-dessous
				//pour afficher le r�sultat sur la sortie standard
				//StreamResult res = new StreamResult(System.out);
		//*****************************************************************************************************//
				//La sortie sur fichier est vue par JAXP comme un cas particulier de transformation.

				//Obtention d'une instance de "TransformerFactory".
				TransformerFactory transform = TransformerFactory.newInstance();
				//Cr�ation du transformateur "tr".
				Transformer tr = transform.newTransformer();
				//Syntaxe abr�g�e des deux pr�c�dentes lignes de code.
				//Transformer tr = TransformerFactory.newInstance().newTransformer();
		//*****************************************************************************************************//
				//Sp�cification de l'encodage.
				tr.setOutputProperty(OutputKeys.ENCODING, "UTF8");
				//Indentation automatique du code source XML.
				tr.setOutputProperty(OutputKeys.INDENT, "yes");
				//Ligne de cr�ation du lien vers la DTD.
				//tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "neruda.dtd");
				//Transformation du document source (source XML) en un r�sultat (fichier XML).
				tr.transform(ds, res);
		poemContinuation("create.xml");
	}
public static void poemContinuation(String xmlFile6) throws Exception{
	/*dans cette deuxieme partie j'extrais simplement les phrases du fichier source create et je cree un fichier de sortie*/
	Document document_src = parser.parse(xmlFile6);


	DOMImplementation domimp = imp();





		Document document_but =	domimp.createDocument(null,"poema", null);
		Element rac_but= document_but.getDocumentElement();
		NodeList titre =  document_src.getElementsByTagName("titre");
		String contenuee = titre.item(0).getFirstChild().getNodeValue();
		document_but.setXmlStandalone(true);
		Element rr = document_but.createElement("titulo");
		rac_but.appendChild(rr);
		rr.appendChild(document_but.createTextNode(contenuee));


		NodeList mot =  document_src.getElementsByTagName("pp");


				 for (int i=0;i<mot.getLength();i++){
				 NodeList liste = mot.item(i).getChildNodes();
				 Element textee = document_but.createElement("estrofa");
					rac_but.appendChild(textee);

				 for (int o=0;o<liste.getLength();o++){
					 NodeList listee = liste.item(o).getChildNodes();

					 for (int j=0;j<listee.getLength();j++){

						if(listee.item(j).getNodeValue()!=null &&  !listee.item(j).getNodeValue().replace("\n","").replace("\t", "").replace(" ","").isEmpty())
						{	String contenu=listee.item(j).getNodeValue().replace("\n","");


		Element texte = document_but.createElement("verso");
		textee.appendChild(texte);
		texte.appendChild(document_but.createTextNode(contenu));} }
				 }}

		StreamResult res = new StreamResult(new File("Resultat/neruda.xml"));
		TransformerFactory transform = TransformerFactory.newInstance();
		Transformer tr = transform.newTransformer();

		DOMSource ds = new DOMSource(document_but);
		tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "neruda.dtd");
		tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		tr.transform(ds, res);
		InputStream is = new FileInputStream("Resultat/neruda.xml");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		String line = buf.readLine();
		StringBuilder sb = new StringBuilder();
		while(line != null) {
			sb.append(line.replaceAll("^ {4}", "\t").replaceAll("^\t {4}", "\t\t").replaceAll("^\t\t {4}", "\t\t\t").replaceAll("\t\t\t {4}", "\t\t\t\t")).append("\r\n");
			line = buf.readLine();
		}
		is.close();
		OutputStream os = new FileOutputStream("Resultat/neruda.xml");
		os.write(sb.toString().getBytes("UTF-8"));
		os.close();
}}




